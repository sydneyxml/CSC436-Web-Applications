export const environment = {
  production: true,
  runningOS: 'Linux',
  firebaseConfig : {
    apiKey: "AIzaSyDZtwtH4t78kqaw7Xoi8re4F4ucPdG7Goo",
    authDomain: "depaul-demo-3acb4.firebaseapp.com",
    databaseURL: "https://depaul-demo-3acb4.firebaseio.com",
    projectId: "depaul-demo-3acb4",
    storageBucket: "depaul-demo-3acb4.appspot.com",
    messagingSenderId: "961560481068",
    appId: "1:961560481068:web:982743f7ca5a7f7241f089",
    measurementId: "G-384DWMTPBX"    
  }  
};
