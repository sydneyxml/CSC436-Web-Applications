import { MustMatchDirective } from './match-value.directive';

describe('MatchValueDirective', () => {
  it('should create an instance', () => {
    const directive = new MustMatchDirective();
    expect(directive).toBeTruthy();
  });
});
