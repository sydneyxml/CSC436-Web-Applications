1) Configure Firebase as indicated here https://firebase.google.com/docs/auth
2) Add Firebase import npm install @angular/fire firebase --save
3) Define AuthService
4) Generate LoginComponent
5) Define Guard
