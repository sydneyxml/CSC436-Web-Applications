# Sample code for CSC436

## Basic Angular using Angular CLI
## Bootstrap
## Routing
## Service
## Authentication
## Github.io to host